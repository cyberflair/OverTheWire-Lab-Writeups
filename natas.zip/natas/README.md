# Natas Writeups

Writeups for the [Natas](https://overthewire.org/wargames/natas/) wargame, which teaches the basics of server-side web security. Each level lives in its own folder, so scripts and screenshots can sit next to the writeup.

Passwords are redacted.

## Levels

- [Level 0](./level00)
- [Level 1](./level01)
- [Level 2](./level02)
- [Level 3](./level03)
- [Level 4](./level04)
- [Level 5](./level05)
- [Level 6](./level06)
- [Level 7](./level07)
- [Level 8](./level08)
- [Level 9](./level09)
- [Level 10](./level10)
- [Level 11](./level11)
- [Level 12](./level12)
- [Level 13](./level13)
- [Level 14](./level14)
- [Level 15](./level15)
- [Level 16](./level16)
- [Level 17](./level17)
- [Level 18](./level18)
- [Level 19](./level19)
- [Level 20](./level20)
- [Level 21](./level21)
- [Level 22](./level22)
- [Level 23](./level23)
- [Level 24](./level24)
- [Level 25](./level25)
- [Level 26](./level26)
- [Level 27](./level27)
- [Level 28](./level28)
- [Level 29](./level29)
- [Level 30](./level30)
- [Level 31](./level31)
- [Level 32](./level32)
- [Level 33](./level33)
