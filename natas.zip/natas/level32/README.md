# Natas Level 32

**URL:** `http://natas32.natas.labs.overthewire.org`

## Goal

_What does this level ask for?_

## Approach

_How did you think about it? What did you notice?_

## Solution

```bash
# commands, requests, or scripts used
```

## Password for next level

`[REDACTED]`

## Takeaways

_What vulnerability or concept does this level teach?_
